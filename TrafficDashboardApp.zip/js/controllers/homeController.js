trafficApp.controller("homeController",['$scope','$rootScope','$location','DataServices','$stomp', '$cookieStore','$timeout',function($scope,$rootScope,$location,DataServices,$stomp,$cookieStore,$timeout){
	
	$scope.selectedPortfolio = "";
	$scope.trafficValue = 25;
	$scope.bestHour = '10a-11a';
	$scope.bestDay = 'Monday';
	$scope.loading = false;
	$scope.m_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	$scope.d = new Date();
	$scope.curr_date = $scope.d.getDate();
	$scope.curr_month = $scope.d.getMonth();
	$scope.curr_year = $scope.d.getFullYear();
	$scope.currentDay = $scope.curr_date + " " + $scope.m_names[$scope.curr_month] + " " + $scope.curr_year;
	$scope.datepicker = $scope.curr_date + " " + $scope.m_names[$scope.curr_month] + " " + $scope.curr_year;

	//$( "#datepicker" ).datepicker({ dateFormat: 'dd MM yy' });
	var date = new Date();
    date.setDate(date.getDate() + 1);

    
	/*$('input.date').datepicker({
    beforeShow: function(input, inst)
    {
        inst.dpDiv.css({marginTop: -input.offsetHeight + 'px', marginLeft: input.offsetWidth + 'px'});
    }
	});*/
	$("#datepicker").datepicker({
        dateFormat: "dd MM yy",
        minDate: date	
		
    });
	$("#datepicker").datepicker("setDate", date);

	$scope.labels = ['6AM-8AM', '8AM-10AM', '10AM-12Noon', '12Noon-2PM', '2PM-4PM', '4PM-6PM', '6PM-8PM', '8PM-10PM'];
  	$scope.series = ['This week', 'Last week'];
  	$scope.data = [
    	[65, 59, 80, 81, 56, 55, 40],
    	[28, 48, 40, 19, 86, 27, 90]
  	];
  	$scope.onClick = function (points, evt) {
    	console.log(points, evt);
  	};

  	$scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
  	$scope.options = {
  		legend: {display: true},
    	scales: {
      		yAxes: [
	        	{
			      	id: 'y-axis-1',
			      	type: 'linear',
			      	display: true,
			      	position: 'left'
	        	},
	        	{
			        id: 'y-axis-2',
			        type: 'linear',
			        display: true,
			        position: 'right'
	        	}
      		],
            xAxes: [{
                display: true
            }]
    	}
    };
	$scope.colors1 = [{
		backgroundColor: '#13D6E9',
        pointBackgroundColor: '#13D6E9',
        pointHoverBackgroundColor: '#13D6E9',
        borderColor: '#13D6E9',
        pointBorderColor: '#13D6E9',
        pointHoverBorderColor: '#13D6E9'
	},
	{
		backgroundColor: '#EF247E',
        pointBackgroundColor: '#EF247E',
        pointHoverBackgroundColor: '#EF247E',
        borderColor: '#EF247E',
        pointBorderColor: '#EF247E',
        pointHoverBorderColor: '#EF247E'
	}];
	$scope.series2 = ['Tomorrow'];
  	$scope.data2 = [
    	[28, 48, 40, 19, 86, 27, 90]
  	];
	$scope.colors2 = [{
		backgroundColor: '#4780D9',
        pointBackgroundColor: '#4780D9',
        pointHoverBackgroundColor: '#4780D9',
        borderColor: '#4780D9',
        pointBorderColor: '#4780D9',
        pointHoverBorderColor: '#4780D9'
	}];
	
	/**
	 * Method : Connect
	 * method used to broadcast the messages from server to client to all logging as
	 * Offshore specialist and messages will be shown using ticker and alert icon.
	 */
	$scope.connect = function() {
		$stomp.connect('http://157.227.254.232:8080/alert').then(function (frame) {
			// Stomp is subscribing the messages.
			  $stomp.subscribe('/broadcast/messages', function (payload, headers, res) {
			  	console.log (payload)
	         	$scope.trafficValue = payload.facedetectionCount;
	         	$scope.$apply();
	        });
		});
    };


	$scope.connect(); 

	
}]);