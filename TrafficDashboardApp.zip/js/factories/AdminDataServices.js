trafficApp.factory('AdminDataServices', ['$rootScope','$http',
    function ($rootScope, $http, $q) {
	
}
]);